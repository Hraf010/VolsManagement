﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VolsManagement.Entities;

namespace VolsManagement.Services
{
    public class VolsServiceImpl : IVolsService
    {
        public VolsManagmentRepository VolsManagmentRepository { get; set; }
        public VolsServiceImpl(VolsManagmentRepository VolsManagmentRepository)
        {
            this.VolsManagmentRepository = VolsManagmentRepository;
        }
        public IEnumerable<Vol> GetAllVols()
        {
            return VolsManagmentRepository.Vols;
        }
    }
}
