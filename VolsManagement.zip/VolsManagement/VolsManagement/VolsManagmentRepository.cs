﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VolsManagement.Entities;

namespace VolsManagement
{
    public class VolsManagmentRepository : DbContext
    {
        public DbSet<Vol> Vols { get; set; }
        public VolsManagmentRepository(DbContextOptions<VolsManagmentRepository> options) : base(options)
        {

        }

        public VolsManagmentRepository()
        {
        }
    }
}
