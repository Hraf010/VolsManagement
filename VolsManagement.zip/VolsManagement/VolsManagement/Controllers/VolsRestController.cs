﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VolsManagement.Entities;
using VolsManagement.Services;

namespace VolsManagement.Controllers
{
    [Route("api/vols")]
    public class VolsRestController : Controller
    {
        public VolsServiceImpl VolsServiceImpl { get; set; }

        public VolsRestController(VolsManagmentRepository VolsManagmentRepository)
        {
            this.VolsServiceImpl = new VolsServiceImpl(VolsManagmentRepository);
        }

        [HttpGet]
        public IEnumerable<Vol> listVols()
        {
            return VolsServiceImpl.GetAllVols();
        }


    }
}
