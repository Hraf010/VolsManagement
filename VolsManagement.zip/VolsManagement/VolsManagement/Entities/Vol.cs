﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace VolsManagement.Entities
{
    public class Vol
    {
        [Display(Name = "Vol ID")]
        public int VolId { get; set; }
        [Required, MinLength(6), MaxLength(25)]
        public string Destination { get; set; }
        [Required, Range(100, 1000000)]
        public double Prix { get; set; }
        [Required, MinLength(6), MaxLength(25)]
        public string Depart { get; set; }
        [Required, Range(10, 50)]
        public int NbrPlaceMax { get; set; }
        [Required, Range(0, 50)]
        public int NbrPlaceDispo { get; set; }
        [Required]
        public DateTime DateDepart { get; set; }

    }
}
