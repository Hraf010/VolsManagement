﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VolsManagement.Entities;
using VolsManagement.Services;

namespace VolsManagement.Controllers
{
    public class VolController : Controller
    {
        private IVolsService _volsService { get; set; }

        public VolController(VolsManagmentRepository volsManagmentRepository)
        {
            _volsService = new VolsServiceImpl(volsManagmentRepository);
        }

        public IActionResult Index()
        {
            IEnumerable<Vol> vols = _volsService.GetAllVols();
            return View("Vols", vols);
        }
    }
}
