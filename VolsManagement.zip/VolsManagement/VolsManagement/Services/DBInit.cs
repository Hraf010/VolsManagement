﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VolsManagement.Entities;

namespace VolsManagement.Services
{
    public class DBInit
    {
        public static void initData(VolsManagmentRepository volsDB)
        {
            Console.WriteLine("Data initialization...");
            volsDB.Vols.Add(new Vol { Destination = "Paris", Depart = "Casablanca", DateDepart = new DateTime(), Prix = 599.99, NbrPlaceMax = 40, NbrPlaceDispo = 40 });
            volsDB.Vols.Add(new Vol { Destination = "Paris", Depart = "Casablanca", DateDepart = new DateTime(), Prix = 599.99, NbrPlaceMax = 40, NbrPlaceDispo = 40 });
            volsDB.Vols.Add(new Vol { Destination = "Paris", Depart = "Casablanca", DateDepart = new DateTime(), Prix = 599.99, NbrPlaceMax = 40, NbrPlaceDispo = 40 });

            volsDB.SaveChanges();

        }
    }
}
